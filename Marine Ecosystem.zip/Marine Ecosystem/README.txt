SI1336 Final Project
Marine Ecosystem
Koray Amico Kulbay

In the folder "Python Code" my source code for the project is found. 
- animals.py and ecosystem.py holds all functionality.
- code_run.py holds different ways to plot an ecosystem. 
Case example: In code_run.py run the code after line 193. 

In the folder "Animation videos" two animations of different ocean sizes and density are pre-recorded.
The yellow individual is a predator, marked so that one can follow the life of a single predator and see its movements. 