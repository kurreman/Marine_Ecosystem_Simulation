# These are the classes of the animals to be used in the ecosystem 

class Animal():
    """A general animal, holds attributes common for all species."""
    def __init__(self,p_mate,p_kill):
        #Biological variables
        self.age = 0
        self.p_mate = p_mate #Probability of mating when meeting other individual of same species
        self.p_kill = p_kill #Probability that animal eats food when found 
        self.x = None
        self.y = None
        self.alive = True #When created it's alive 

    def _assign_coord(self,x,y):
        self.x = x
        self.y = y

class Producer(Animal):
    def __init__(self,p_mate,p_kill):
        Animal.__init__(self,p_mate=p_mate,p_kill=p_kill) #init of producer overrides init of Animal. This gives both
        self.life_span = 10
        self.nutri_val = 1
        self.speed = 10
        self.food = None  #Species that it eats
        self.hunter = "<class 'animals.Herbivore'>" #type(Herbivore()) #Species that eats it
        #Animation
        self.pic = None #Later to be used for picture to be plotted
        self.color = "g"

class Herbivore(Animal): #Consumer
    def __init__(self,p_mate,p_kill):
        Animal.__init__(self,p_mate=p_mate,p_kill=p_kill)
        self.life_span = 100
        self.nutri_val = 2
        self.speed = 20
        self.food = "<class 'animals.Producer'>" #type(Producer())  
        self.hunter = "<class 'animals.Carnivore'>" #type(Carnivore()) 
        #Animation
        self.pic = None
        self.color = "m"

class Carnivore(Animal):
    def __init__(self,p_mate,p_kill):
        Animal.__init__(self,p_mate=p_mate,p_kill=p_kill)
        self.life_span = 150
        self.nutri_val = 3
        self.speed = 30
        self.food = "<class 'animals.Herbivore'>" #type(Herbivore())  
        self.hunter = "<class 'animals.Predator'>" #type(Predator()) 
        #Animation
        self.pic = None
        self.color = "r"

class Predator(Animal):
    def __init__(self,p_mate,p_kill):
        Animal.__init__(self,p_mate=p_mate,p_kill=p_kill)
        self.life_span = 180
        self.nutri_val = 4
        self.speed = 40
        self.food = "<class 'animals.Carnivore'>" #type(Carnivore())  
        self.hunter = None 
        #Animation
        self.pic = None
        self.color = "k"