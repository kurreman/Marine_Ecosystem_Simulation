from ecosystem import Ocean
import matplotlib.pyplot as plt
import numpy as np

def plot_p_mate_vs_score():
    """Plots biodiagram for different p_mate"""
    p_l = [0.1,0.8] #p_mate

    ocean_size = 10
    max_step = 10
    #p_mate = 0.1
    p_kill = 1
    numFrames = 200

    fig = plt.figure()
    for p in p_l:
        plot_i = biodiagram(run_plot=False,p_mate=p)
        plt.plot(plot_i[0], plot_i[1],label="p_mate = {}".format(p))
    plt.title("Biodiagram and p_mate")
    plt.xlabel("Initial density")
    plt.ylabel("Biodiversity score")
    plt.figtext(0,0,"ocean size {0}, max_step {1}, p_mate {2}, p_kill {3}, numFrames/ocean {4}".format(ocean_size,max_step, "see plot", p_kill, numFrames))
    plt.legend()
    plt.show()

def plot_p_kill_vs_score():
    """Plots biodiagram for different p_kill"""
    p_l = [1,0.2] #p_kill

    ocean_size = 10
    max_step = 10
    p_mate = 0.1
    #p_kill = 1
    numFrames = 200

    fig = plt.figure()
    for p in p_l:
        plot_i = biodiagram(run_plot=False,p_kill=p)
        plt.plot(plot_i[0], plot_i[1],label="p_kill = {}".format(p))
    plt.title("Biodiagram and p_kill")
    plt.xlabel("Initial density")
    plt.ylabel("Biodiversity score")
    plt.figtext(0,0,"ocean size {0}, max_step {1}, p_mate {2}, p_kill {3}, numFrames/ocean {4}".format(ocean_size,max_step, p_mate, "see plot", numFrames))
    plt.legend()
    plt.show()

def plot_ocean_size_vs_score():
    """Plots biodiagram for different ocean sizes"""
    sizes = [4,6,8,10,12,14,16,18,20]

    #ocean_size = 10
    max_step = 10
    p_mate = 0.1
    p_kill = 1
    numFrames = 200

    fig = plt.figure()
    for size in sizes:
        plot_i = biodiagram(run_plot=False,ocean_size=size)
        plt.plot(plot_i[0], plot_i[1],label="Ocean size = {}".format(size))
    plt.title("Biodiagram and ocean size")
    plt.xlabel("Initial density")
    plt.ylabel("Biodiversity score")
    plt.figtext(0,0,"ocean size {0}, max_step {1}, p_mate {2}, p_kill {3}, numFrames/ocean {4}".format("see plot",max_step, p_mate, p_kill, numFrames))
    plt.legend()
    plt.show()

def plot_step_size_vs_score(mean=False):
    """Plots biodiagram for different max step sizes"""
    step_sizes = [1,5,10]

    ocean_size = 10
    #max_step = 10
    p_mate = 0.1
    p_kill = 1
    numFrames = 200

    fig = plt.figure()
    if mean:
        numSim = 5
        for max_step in step_sizes:
            plot_i = biodiagram_mean(run_plot=False,max_step=max_step,numSim=numSim)
            plt.plot(plot_i[0], plot_i[1],label="Maximum step size = {}".format(max_step))
            plt.errorbar(plot_i[0], plot_i[1],yerr=plot_i[2],every=10,fmt='none', label="standard deviation")
        plt.title("Mean Biodiagram and maximum step size | numSim/step_size = {}".format(numSim))
        plt.ylabel("Mean Biodiversity score")
    else:
        for max_step in step_sizes:
            plot_i = biodiagram(run_plot=False,max_step=max_step)
            plt.plot(plot_i[0], plot_i[1],label="Maximum step size = {}".format(max_step))
        plt.title("Biodiagram and maximum step size")
        plt.ylabel("Biodiversity score")
    plt.xlabel("Initial density")
    plt.figtext(0,0,"ocean size {0}, max_step {1}, p_mate {2}, p_kill {3}, numFrames/ocean {4}".format(ocean_size,"see plot", p_mate, p_kill, numFrames))
    plt.legend()
    plt.show()

def biodiagram(run_plot=True,simNum=None,ocean_size=10,max_step=10,p_mate=0.1,p_kill=1,numFrames=200):
    """Plots maximum biodiversity score for different densities"""
    ocean_size = ocean_size
    max_pop = ocean_size**2/4 #4 different species
    step_size = max_pop/10
    pop_size = int(np.ceil(step_size)) #We have uniform distr. of species
    plot = [[],[]] #x,y | initial densities, BIOscore for ocean of that density
    run = 1
    total_runs = int(max_pop/step_size)-1
    frames_per_ocean = 0
    try:
        while pop_size < max_pop:
            ocean = Ocean(size=ocean_size,nProducers=pop_size,nHerbivores=pop_size,nCarnivores=pop_size,nPredators=pop_size,stat_collect=True,max_step=max_step,p_mate=p_mate,p_kill=p_kill, numFrames=numFrames)
            ocean.alive(non_anim=True)
            score = np.mean(ocean.ocean_bio_div_score())
            density = 4*pop_size/ocean_size**2 # species/m^2
            plot[0].append(density)
            plot[1].append(score)
            print("Finished density run {0} / {1} at density = {2}".format(run,total_runs,4*pop_size/ocean_size**2))
            pop_size = int(np.ceil(pop_size + step_size))
            print("ocean {0}, max_step {1}, p_mate {2}, p_kill {3},numFrames{4},simNum {5}".format(ocean_size,max_step,p_mate,p_kill,numFrames,simNum))
            run += 1
            if frames_per_ocean == 0:
                frames_per_ocean = ocean.numFrames
    except KeyboardInterrupt:
        pass
    if run_plot:
        fig = plt.figure()
        plt.plot(plot[0], plot[1])
        plt.title("Biodiversity vs ocean density")
        plt.xlabel("Initial density")
        plt.ylabel("Maximum ocean biodiversity score")
        plt.figtext(0,0,"Number of frames per ocean = {}".format(frames_per_ocean))
        plt.show()
    else:
        return plot

def biodiagram_mean(numSim,run_plot=True,max_step=10):
    """Runs biodiagram numSim times and plots mean value with errorbars"""
    densities_l = []
    bio_scores_l = []
    
    for i in range(numSim):
        plot_i = biodiagram(run_plot=False,simNum=i,max_step=max_step)
        densities_l.append(plot_i[0])
        bio_scores_l.append(plot_i[1])

    densities_plt = densities_l[0]
    bio_scores_plt = []
    error_bars = []
    for i in range(len(bio_scores_l[0])): #length of bio_score list of run 1
        scores_at_density_i = []
        for simulation in bio_scores_l:
            try:
                scores_at_density_i.append(simulation[i])
            except IndexError:
                pass
        bio_scores_plt.append(np.mean(scores_at_density_i))
        SEM = np.sqrt(np.var(scores_at_density_i)/(len(scores_at_density_i)-1))
        error_bars.append(SEM)

    if run_plot:
        fig = plt.figure()
        plt.plot(densities_plt, bio_scores_plt)
        plt.title("Mean biodiversity vs ocean density")
        plt.xlabel("Initial density")
        plt.errorbar(densities_plt,bio_scores_plt,yerr=error_bars,every=10,fmt='none', label="standard deviation")
        plt.ylabel("Mean ocean biodiversity score")
        plt.legend()
        plt.figtext(0,0,"Number of simulations = {}".format(numSim))
        plt.show()
    else:
        plot = [densities_plt, bio_scores_plt, error_bars]
        return plot

def stat_acc():
    """Runs several simulations of same parameters."""
    ocean_size = 10
    pop_size = 10
    runs = 0
    bio_score_l = []
    SEM = 10**5  # Large number to initiate

    while SEM > 0.01:
        ocean = Ocean(size=ocean_size,nProducers=pop_size,nHerbivores=pop_size,nCarnivores=pop_size,nPredators=pop_size)
        ocean.alive(non_anim=True)
        bio_score = np.mean(ocean.ocean_bio_div_score()) #Maybe mean is better
        bio_score_l.append(bio_score)
        runs +=1
        if runs > 1:  #Nothing statistical about only one sample
            curr_SEM = np.sqrt(np.var(bio_score_l)/(runs-1))  #Standard Error of Mean
            SEM = curr_SEM
            print(SEM,runs)
    print("SEM = {0}, runs = {1}, density = {2}, ocean_size = {3}".format(SEM,runs,4*pop_size/ocean_size**2,ocean_size))

#Run the following to show an animation of an ocean of size 1000 and uniform initial species distribution.
ocean = Ocean(size=1000,nProducers=20,nHerbivores=20,nCarnivores=20,nPredators=20)
ocean.alive(non_anim=False)
ocean.plot_concentration()

