#The ecosystem

import copy
import numpy as np
import animals
import random as rnd
#rnd.seed(300) # UNCOMMENT TO SET RANDOM SEED
import matplotlib.pyplot as plt
from matplotlib import animation
import matplotlib

img = plt.imread("ocean.jpg")

class _Cell():
    """Single cell of grid"""
    def __init__(self,x=None,y=None):
        self.x = x
        self.y = y
        self.occupied = False
        self.animal = None
    
    def _clear(self):
        """Cleares cell except for it's position"""
        self.occupied = False
        self.animal = None
    
    def _assign(self,animal):
        """Assigns animal to cell and makes it occupied"""
        self.animal = animal
        self.occupied = True

class Ocean():
    """Ocean that holds all species. Mandatory ocean size and initial species population sizes."""

    def __init__(self,size,nProducers,nHerbivores,nCarnivores,nPredators,stat_collect=False,max_step=10,p_mate=0.1,p_kill=1,numFrames=200): 
        #Biological variables
        self.individuals = {}
        self.max_nmbr_pop = 10**6 #Basically no population size limit
        self.size = size
        self.nutri_pool = 0

        #Stability and statistics
        self.stable_holder = False
        self.stable = False
        self.conc_prod = []
        self.conc_herb = []
        self.conc_carn = []
        self.conc_pred = []

        self.bio_div = []
        self.domination = False

        self.p_mate = p_mate
        self.p_kill = p_kill

        #init grid
        self.grid = np.zeros((size, size),dtype= type(_Cell))
        for i in range(size):
            for j in range(size):
                self.grid[i,j] = _Cell(x=i,y=j)
        self.place_animals(nProducers,nHerbivores,nCarnivores,nPredators)

        #Animation
        self.init_prod = nProducers
        self.init_herb = nHerbivores
        self.init_carn = nCarnivores
        self.init_pred = nPredators
        
        self.max_step_size = max_step

        self.numFrames = numFrames
        self.non_anim = None
        if not stat_collect:
            self.fig = plt.figure()
            self.canvas = self.fig.add_subplot(111) 
            self.canvas.axis('off')
            self.canvas.set_xlim([0,size])
            self.canvas.set_ylim([0,size])
        
    def _add_ind(self,ind):
        """Adds individual with already assigned coordinates. PLACES IN INDIVIDUALS DICT """
        if ind.x == None or ind.y == None or ind.age == None:
            raise AttributeError("Added individual is missing coordinates or has been removed before.")
    
        if isinstance(ind, animals.Producer):
            try: 
                self.individuals["Producer"].append(ind)
            except KeyError:
                self.individuals["Producer"] = [ind]
        elif isinstance(ind, animals.Herbivore):
            try: 
                self.individuals["Herbivore"].append(ind)
            except KeyError:
                self.individuals["Herbivore"] = [ind]
        elif isinstance(ind, animals.Carnivore):
            try: 
                self.individuals["Carnivore"].append(ind)
            except KeyError:
                self.individuals["Carnivore"] = [ind]
        elif isinstance(ind, animals.Predator):
            try: 
                self.individuals["Predator"].append(ind)
            except KeyError:
                self.individuals["Predator"] = [ind]
        
    
    def _remove_ind(self,ind):
        """Removes individual from ocean"""
        ind.x = None
        ind.y = None
        ind.age = None
        ind.alive = False
        if isinstance(ind, animals.Producer):
            
            self.individuals["Producer"].remove(ind)

        elif isinstance(ind, animals.Herbivore):
            self.individuals["Herbivore"].remove(ind)

        elif isinstance(ind, animals.Carnivore):
            self.individuals["Carnivore"].remove(ind)
            
        elif isinstance(ind, animals.Predator):
            self.individuals["Predator"].remove(ind)
            

    def place_animals(self,nProducers,nHerbivores,nCarnivores,nPredators):
        """Places initial number of species in ocean."""
        self._place_species_rnd(nProducers,"Prod")
        self._place_species_rnd(nHerbivores,"Herb")
        self._place_species_rnd(nCarnivores,"Carn")
        self._place_species_rnd(nPredators,"Pred")
    
    def _rnd_coord_generator(self):
        """Returns random coordinates x,y and cell of an unoccupied cell"""
        x = rnd.randint(0,self.size-1)
        y = rnd.randint(0,self.size-1)
        cell = self.grid[x,y]
        while cell.occupied:
            x = rnd.randint(0,self.size-1)
            y = rnd.randint(0,self.size-1)
            cell = self.grid[x,y]
        return x,y,cell


    def _place_species_rnd(self,nSpecies,species):
        for i in range(nSpecies):
            x,y,cell = self._rnd_coord_generator()
            if species == "Prod":
                animal = animals.Producer(p_mate=self.p_mate,p_kill=self.p_kill)
            elif species == "Herb":
                animal = animals.Herbivore(p_mate=self.p_mate,p_kill=self.p_kill)
            elif species == "Carn":
                animal = animals.Carnivore(p_mate=self.p_mate,p_kill=self.p_kill)
            elif species == "Pred":
                animal = animals.Predator(p_mate=self.p_mate,p_kill=self.p_kill)
            animal.x = x
            animal.y  = y    
            cell._assign(animal)
            
            self._add_ind(animal)

    def _place(self,ind,x,y):
        """Place individual at cell x,y in ocean. PLACES IN GRID"""
        #Assign new coordinates to individual
        ind._assign_coord(x,y)

        #Move individudal to new cell
        cell = self.grid[x,y]
        cell._assign(ind)
    
    def _kill_ind(self,ind,x,y):
        """Kills individual and clear cell x,y"""
        self._remove_ind(ind)
        self.grid[x,y]._clear()

    
    def _neighbours(self,x,y):
        """Returns list of 8 neighbours to given cell coordinates x,y."""
        margin = 1
        try:
            n1 = self.grid[x-margin,y+margin]
        except:
            n1 = None
        try:
            n2 = self.grid[x,y+margin]
        except:
            n2 = None
        try:
            n3 = self.grid[x+margin,y+margin]
        except:
            n3 = None
        try:
            n4 = self.grid[x+margin,y]
        except:
            n4 = None
        try:
            n5 = self.grid[x+margin,y-margin]
        except:
            n5 = None
        try:
            n6 = self.grid[x,y-margin]
        except:
            n6 = None
        try:
            n7 = self.grid[x-margin,y-margin]
        except:
            n7 = None
        try:
            n8 = self.grid[x-margin,y]
        except:
            n8 = None
        return [n1,n2,n3,n4,n5,n6,n7,n8]

    def _full(self):
        """Returns True if ocean is full of individuals"""
        tot_individuals = 0
        for pop in self.individuals.values():
            tot_individuals += len(pop)
        if tot_individuals == self.size**2:
            return True
        else:
            return False
    
    def _pop_max(self,ind=None,producer=False):
        """Returns True if population of ind has reached maximum size"""
        pop_size = 0
        if isinstance(ind, animals.Producer) or producer:
            pop_size = len(self.individuals["Producer"])

        elif isinstance(ind, animals.Herbivore):
            pop_size = len(self.individuals["Herbivore"])

        elif isinstance(ind, animals.Carnivore):
            pop_size = len(self.individuals["Carnivore"])
            
        elif isinstance(ind, animals.Predator):
            pop_size = len(self.individuals["Predator"])
        
        if pop_size >= self.max_nmbr_pop:
            return True 
        else:
            return False


    def _cell_auto_rules(self,ind,x,y):    
        n_l = self._neighbours(x,y)  #list of neighbours

        for neigh in n_l:
            if neigh and neigh.animal:
                #1. Any species (but Producer) meet same species 
                # => creates +1 individual with proabaility p_mate (mating) if food is available

                if (type(neigh.animal) == type(ind) and 
                    self.food_available(ind) and 
                        not isinstance(ind, animals.Producer) and 
                            not self._full() and
                                not self._pop_max(ind=ind)):
                    if rnd.randint(0,100) < ind.p_mate*100:  #Probability of mating
                        baby = copy.deepcopy(ind)
                        baby.age = 0
                        x_baby,y_baby,cell = self._rnd_coord_generator()
                        baby.x = x_baby 
                        baby.y = y_baby
                        self._place(baby, x_baby, y_baby)
                        self._add_ind(baby)
                #2. When food species meet hunter species => food dies with probablitity p_kill  => n_v_hunter += n_v_food
                if ind.age or ind.age == 0:
                    if neigh.animal.food == str(type(ind)):
                        if rnd.randint(0,100) < ind.p_kill*100:  #Probability of killing
                            neigh.animal.nutri_val += ind.nutri_val
                            self._kill_ind(ind,x,y)
                            

                    elif neigh.animal.hunter == str(type(ind)):
                        if rnd.randint(0,100) < ind.p_kill*100:  
                            ind.nutri_val += neigh.animal.nutri_val
                            self._kill_ind(neigh.animal,neigh.animal.x,neigh.animal.y)
                        
        #3. When age=life_span of individual => dies => nutri_pool += n_v
        if (ind.age or ind.age == 0) and ind.age >= ind.life_span:
            self.nutri_pool += ind.nutri_val
            self._kill_ind(ind,x,y)
            
        #4. If nutri_pool > 0 => +1 plankton for each n_v
        for i in range(self.nutri_pool):
            if not self._full() and not self._pop_max(producer=True):
                baby_p = animals.Producer(p_mate=self.p_mate,p_kill=self.p_kill)
                x_bp,y_bp,cell = self._rnd_coord_generator()
                baby_p.x = x_bp
                baby_p.y = y_bp
                self._place(baby_p, x_bp, y_bp)
                self._add_ind(baby_p)
                self.nutri_pool -= 1 # TODO
        
    

    def _border_check(self,x,y):
        """Handles coordinates outside ocean border"""

        if x >= self.size: 
            x = abs(x%self.size)
        elif x < 0:
            x = self.size-1 + x
        if y >= self.size:
            y = None  #Fish can't swim above surface 
        elif y < 0:
            y = None #or in bottom
        return x,y

    def food_available(self,individual):
        """Returns True if there exists food for the individual in ocean."""
        food = 0
        for pop in self.individuals.values():
            for ind in pop:
                if str(type(ind)) == individual.food:
                    food += 1 
                    break
        if food > 0:
            return True
        else:
            return False
    

    def move(self,ind,x,y):
        """Random movement of individual"""
        x_new = x 
        y_new = y 
        cell = self.grid[x_new,y_new]
        #5. If cell occupied => dont go there. (If surrounded => stay put
        #try:
        step = self.max_step_size  #Step important to get data based on movement. Small step (==1) gives "sqaure" behaviour
        tries = 0
        max_tries = 10
        while cell.occupied:  
            tries += 1
            x_new = (x + rnd.randint(-step,step)) % self.size #% is if max_step_size is huge and we cross over maximum allowed step
            y_new = (y + rnd.randint(-step,step)) % self.size
            x_new, y_new = self._border_check(x_new,y_new)
            if y_new == None:
                y_new = y
            cell = self.grid[x_new,y_new]
            if tries == max_tries: #Too long run time.
                break
        
        if tries < max_tries:
            #Move ind to new cell
            self._place(ind,x_new,y_new)
            
            #Remove individual from old cell
            old_cell = self.grid[x,y]
            old_cell._clear()
        

    def _update(self,frame):
        print("frame ", frame)
        tot_ind_nutri = 0
        x_l = []
        y_l = []
        color_l = []
        ctrl = 0
        for pop in self.individuals.values():
            ctrl += 1
            for ind in pop:
                ind.age += 1 #Individual ages 
                tot_ind_nutri += ind.nutri_val
                for i in range(ind.speed):
                    if ind.alive: #Could have died while "running"
                        self.move(ind,ind.x,ind.y)
                        self._cell_auto_rules(ind,ind.x,ind.y)
                if ind.alive: 
                    x_l.append(ind.x)
                    y_l.append(ind.y)
                    if ctrl == 4:
                        color_l.append("gold")
                        ctrl = 5
                    else:
                        color_l.append(ind.color)
        self.stat_collect()
        print("Total nutri = ", tot_ind_nutri+self.nutri_pool)

        if frame > 500 and self.stable_holder:
            self.stable = True

        if not self.non_anim:
            self.canvas.clear()
            self.canvas.axis('off')
            plt.title('Ocean size = {0}, Max step size = {1}, \n init [prod, herb, carn, pred] = [{2},{3},{4},{5}], \n p_mate = {6}, p_kill = {7}'.format(self.size, self.max_step_size,self.init_prod, self.init_herb, self.init_carn, self.init_pred, self.p_mate,self.p_kill))
            self.canvas.set_xlim([0,self.size])
            self.canvas.set_ylim([0,self.size])
            self.canvas.imshow(img,extent=[0, self.size, 0, self.size])
            
            return self.canvas.scatter(x_l, y_l, c=color_l,marker=">"),

            
    def alive(self,non_anim=False):
        """Opens road and plays out the cars movement"""
        self.non_anim = non_anim
        if non_anim: 
            for frame in range(self.numFrames):
                if not self.domination:
                    self._update(frame)
        else:
            
            anim = animation.FuncAnimation(self.fig, func = self._update,
                                frames=self.numFrames, interval=10, blit=False, repeat=False)

                                # func = what gets plotted
                                # frames = values passed in func
                                # Interval = time delay between each frame
            plt.show()

    #------IMPLEMENTATION DONE------#
    def stat_collect(self):
        """Collects statistics for ocean at each frame"""
        self.stable_check()
        self.bio_diversity()

    def bio_diversity(self):
        """Records biodiversity score at a single frame."""
        score = 0
        for pop in self.individuals.values():
            if len(pop) > 0:
                score += 100 + len(pop) #100 is a big score bonus for a new species
        if self.diversity_exists(): #Otherwise a biodiversity score doesn't make sense (if only 1 species is alive)
            self.bio_div.append(score)
        elif not self.diversity_exists():
            self.domination = True

    def diversity_exists(self):
        """Returns True if more than one species is alive"""
        #return True
        species_counter = 0
        for species_pop in self.individuals.values():
            if len(species_pop) > 0:
                species_counter += 1
        if species_counter > 1:
           return True
        else:
           return False

    def concentration(self,species):
        """Returns concentration of species in ocean. 
        Species: "Producer", "Herbivore", "Carnivore", "Predator" """
        pop = self.individuals[species]
        return len(pop)/(self.size**2) #individual/m^2

    def stable_check(self):
        """Updates concentration lists and checks if ocean is stable"""
        new_c_prod = self.concentration("Producer")
        new_c_herb = self.concentration("Herbivore")
        new_c_carn = self.concentration("Carnivore")
        new_c_pred = self.concentration("Predator")
        if len(self.conc_pred) > 0:
            
            if (new_c_prod == self.conc_prod[-1] and 
                new_c_herb == self.conc_herb[-1] and 
                    new_c_carn == self.conc_carn[-1] and 
                        new_c_pred == self.conc_pred[-1] and 
                            new_c_prod != 0 and 
                                new_c_herb != 0 and 
                                    new_c_carn != 0 and 
                                        new_c_pred != 0):
                self.stable_holder = True
            else:
                self.stable_holder = False
        self.conc_prod.append(new_c_prod)
        self.conc_herb.append(new_c_herb)
        self.conc_carn.append(new_c_carn)
        self.conc_pred.append(new_c_pred)
    
    def plot_concentration(self):
        """Plots ocean concentrations after ocean has been alive"""
        x_axis = np.linspace(1,len(self.conc_prod),len(self.conc_prod))

        fig = plt.figure()
        plt.plot(x_axis, self.conc_prod, label="Producers",c="g")
        plt.plot(x_axis, self.conc_herb, label="Herbivores",c="m")
        plt.plot(x_axis, self.conc_carn, label="Carnivores",c="r")
        plt.plot(x_axis, self.conc_pred, label="Predators",c="k")
        plt.title("Concentration vs elapsed time")
        plt.xlabel("Frame")
        plt.ylabel("Population concentration in ocean ")
        plt.legend()
        plt.show()

    def ocean_bio_div_score(self):
        """Calculates ocean biodiversity score per frame and returns data as array."""
        bio_div_scores = []
        for score in self.bio_div:
            bio_div_scores.append(score/self.bio_div[0])
        return bio_div_scores

    def plot_diversity(self, non_anim=False):
        """Plots ocean diversity vs frame/time"""
        x_axis = np.linspace(1,len(self.bio_div),len(self.bio_div))
        bio_div_plot = self.ocean_bio_div_score()
        
        fig = plt.figure()
        plt.plot(x_axis, bio_div_plot)
        plt.title("Biodiversity vs elapsed time")
        plt.xlabel("Frame")
        plt.ylabel("Ocean biodiversity score")
        plt.figtext(0,0,"Initial score = {}".format(self.bio_div[0]))
        plt.show()